;;; Generated from perinf.el; do not edit.
;; -*- no-byte-compile: t; lexical-binding: t; -*-
(define-package "perinf" "1.0.2" "Org-backed work management core" '((emacs "29.1") (org "9.6")) :authors '(("Niels Søndergaard" . "niels@algon.dk")) :maintainer '("Niels Søndergaard" . "niels@algon.dk") :keywords '("outlines" "calendar" "convenience") :url '"https://github.com/algon236/perinf")
