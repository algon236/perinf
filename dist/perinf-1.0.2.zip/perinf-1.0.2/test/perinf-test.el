;;; perinf-test.el --- Bootstrap tests for Personal Work and Information System -*- lexical-binding: t; -*-

;; Copyright (C) 2026, Niels Søndergaard, Nivaa, Denmark.
;; Author: Niels Søndergaard, mail: niels<at>algon.dk

;; SPDX-License-Identifier: GPL-3.0-or-later
;;
;; This file is part of Personal Work and Information System.
;;
;; Personal Work and Information System is free software: you can redistribute
;; it and/or modify it under the terms of the GNU General Public License as
;; published by the Free Software Foundation, either version 3 of the License,
;; or (at your option) any later version.
;;
;; Personal Work and Information System is distributed in the hope that it will
;; be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
;; Public License for more details.
;;
;; You should have received a copy of the GNU General Public License along with
;; this program.  If not, see <https://www.gnu.org/licenses/>.

;;; Code:

(require 'ert)
(require 'perinf)

(defconst perinf-test-root
  (file-name-directory
   (directory-file-name
    (file-name-directory (or load-file-name buffer-file-name))))
  "Repository root used by the bootstrap tests.")

(ert-deftest perinf-test-all-locales-are-complete ()
  (perinf-i18n-load-locales)
  (dolist (locale perinf-i18n-supported-locales)
    (should (equal (perinf-i18n-validate-locale locale)
                   '(:missing nil :unknown nil)))))

(ert-deftest perinf-test-project-metadata-is-readable ()
  (let* ((project (expand-file-name "examples/minimal-project"
                                    perinf-test-root))
         (metadata (perinf-storage-read-project project)))
    (should (equal (alist-get 'PROJECT_ID metadata)
                   "project-example"))
    (should (equal (alist-get 'SCHEMA_VERSION metadata)
                   "1"))))

(ert-deftest perinf-test-start-page-renders-in-danish ()
  (let ((perinf-interface-language 'da)
        (perinf-current-project nil))
    (perinf-i18n-load-locales)
    (with-temp-buffer
      (perinf-mode)
      (perinf-core--render)
      (should (string-match-p "Intet projekt er åbent"
                              (buffer-string))))))

(ert-deftest perinf-test-dashboard-shows-real-project-content ()
  (let* ((parent (make-temp-file "perinf-dashboard-test-" t))
         (project (expand-file-name "dashboard-project" parent))
         (perinf-interface-language 'da))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Dashboard" 'da 'day-month-year-dash
           'twenty-four-hour)
          (perinf-storage-create
           'task
           '((title . "Ring til kommunen")
             (deadline . "2000-01-01"))
           project)
          (perinf-storage-create
           'person '((title . "Anne Jensen")) project)
          (perinf-storage-create
           'meeting
           '((title . "Bestyrelsesmøde")
             (date . "2026-08-12")
             (start-time . "14:00:00"))
           project)
          (let ((perinf-current-project
                 (file-name-as-directory project)))
            (perinf-i18n-load-locales)
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'home)
              (perinf-core--render)
              (should (string-match-p "Overblik" (buffer-string)))
              (should (string-match-p "Opgaver: 1" (buffer-string)))
              (should (string-match-p "Åbne opgaver: 1" (buffer-string)))
              (should
               (string-match-p "Overskredne opgaver: 1" (buffer-string)))
              (should (string-match-p "Møder: 1" (buffer-string)))
              (should (string-match-p "Personer: 1" (buffer-string)))
              (should (string-match-p "Ring til kommunen"
                                      (buffer-string)))
              (should (string-match-p "Bestyrelsesmøde"
                                      (buffer-string)))
              (should-not
               (string-match-p
                "Projektet indeholder endnu ingen registrerede objekter"
                (buffer-string))))
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'work)
              (perinf-core--render)
              (should (string-match-p "Overskredet" (buffer-string))))
            (let ((task
                   (car (perinf-storage-list 'task project))))
              (perinf-storage-update
               (perinf-object-id task)
               '((PERINF_STATUS . completed))
               project)
              (should-not
               (perinf-core--task-overdue-p
                (car (perinf-storage-list 'task project)))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-search-finds-objects-by-title ()
  (let* ((parent (make-temp-file "perinf-search-test-" t))
         (project (expand-file-name "search-project" parent))
         (perinf-interface-language 'da))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Search" 'da 'day-month-year-dash
           'twenty-four-hour)
          (perinf-storage-create
           'task '((title . "Ring til kommunen")) project)
          (perinf-storage-create
           'person '((title . "Anne Jensen")) project)
          (perinf-storage-create
           'meeting
           '((title . "Bestyrelsesmøde")
             (date . "2026-08-12")
             (start-time . "14:00:00"))
           project)
          (let* ((perinf-current-project
                  (file-name-as-directory project))
                 (results (perinf-core--search-objects "MØDE")))
            (should (= (length results) 1))
            (should (eq (perinf-object-type (car results)) 'meeting))
            (should (equal (perinf-object-title (car results))
                           "Bestyrelsesmøde"))
            (perinf-i18n-load-locales)
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'search
                    perinf-search-query "MØDE"
                    perinf-search-results results)
              (perinf-core--render)
              (should (string-match-p "Find objekt" (buffer-string)))
              (should (string-match-p "Resultater: 1" (buffer-string)))
              (should (string-match-p "Møde  Bestyrelsesmøde"
                                      (buffer-string)))
              (setq perinf-current-view 'detail
                    perinf-selected-object (car results))
              (perinf-core--render)
              (should (string-match-p "Type: Møde" (buffer-string)))
              (should (string-match-p "Status: Planlagt" (buffer-string)))
              (should (string-match-p "Dato: 12-08-2026"
                                      (buffer-string)))
              (should (string-match-p "Deltagere" (buffer-string)))
              (should (string-match-p "Dagsordenspunkter"
                                      (buffer-string))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-create-real-project ()
  (let* ((parent (make-temp-file "perinf-project-test-" t))
         (project (expand-file-name "real-project" parent)))
    (unwind-protect
        (let* ((created
                (perinf-project-create
                 project "Real project" 'da 'day-month-year-dash
                 'twenty-four-hour))
               (metadata (perinf-project-read-metadata created)))
          (should (perinf-project-p created))
          (should (equal (alist-get 'PROJECT_TITLE metadata) "Real project"))
          (should (equal (alist-get 'INTERFACE_LANGUAGE metadata) "da"))
          (dolist (file '("data/tasks.org" "data/people.org"
                          "data/contexts.org" "data/decisions.org"))
            (should (file-regular-p (expand-file-name file created))))
          (dolist (directory '("data/meetings" "data/transcripts"
                               "data/minutes" "media/audio" "archive"
                               "config"))
            (should (file-directory-p
                     (expand-file-name directory created)))))
      (delete-directory parent t))))

(ert-deftest perinf-test-create-project-refuses-existing-directory ()
  (let ((directory (make-temp-file "perinf-existing-test-" t)))
    (unwind-protect
        (should-error
         (perinf-project-create
          directory "Existing" 'en 'iso 'twenty-four-hour)
         :type 'user-error)
      (delete-directory directory t))))

(ert-deftest perinf-test-last-project-state-round-trip ()
  (let* ((parent (make-temp-file "perinf-state-test-" t))
         (perinf-state-file (expand-file-name "state/state.el" parent))
         (perinf-last-project-directory "/tmp/perinf-example/"))
    (unwind-protect
        (progn
          (perinf-core--save-state)
          (setq perinf-last-project-directory nil)
          (perinf-core--load-state)
          (should (equal perinf-last-project-directory
                         "/tmp/perinf-example/")))
      (delete-directory parent t))))

(ert-deftest perinf-test-danish-main-menu-and-regional-settings ()
  (let ((perinf-interface-language 'da)
        (perinf-current-project
         (file-name-as-directory
          (expand-file-name "examples/minimal-project" perinf-test-root))))
    (perinf-i18n-load-locales)
    (with-temp-buffer
      (perinf-mode)
      (setq perinf-current-view 'administration)
      (perinf-core--render)
      (dolist (text '("Start" "Arbejde" "Møder" "Arkiv"
                      "Administration" "ÅÅÅÅ-MM-DD" "24-timers ur"))
        (should (string-match-p text (buffer-string)))))))

(ert-deftest perinf-test-danish-date-normalization ()
  (should
   (equal (perinf-date-normalize "31-08-2026" 'day-month-year-dash)
          "2026-08-31"))
  (should-error
   (perinf-date-normalize "08/31/2026" 'day-month-year-dash)
   :type 'user-error))

(ert-deftest perinf-test-task-round-trip-through-storage-api ()
  (let* ((parent (make-temp-file "perinf-task-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Task test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (let* ((created
                  (perinf-storage-create
                   'task
                   '((title . "Ring til kommunen")
                     (deadline . "2026-08-31")
                     (description . "Spørg om mødet."))
                   project))
                 (tasks (perinf-storage-list 'task project))
                 (task (car tasks)))
            (should (string-prefix-p "task-" (perinf-object-id created)))
            (should (= (length tasks) 1))
            (should (equal (perinf-object-title task)
                           "Ring til kommunen"))
            (should (equal
                     (alist-get 'DEADLINE
                                (perinf-object-properties task))
                     "2026-08-31"))))
      (delete-directory parent t))))

(ert-deftest perinf-test-task-status-workflow-through-storage-api ()
  (let* ((parent (make-temp-file "perinf-complete-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Completion test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (let* ((created
                  (perinf-storage-create
                   'task '((title . "Afslut mig")) project))
                 (active
                  (perinf-storage-update
                   (perinf-object-id created)
                   '((PERINF_STATUS . active))
                   project))
                 (waiting
                  (perinf-storage-update
                   (perinf-object-id created)
                   '((PERINF_STATUS . waiting))
                   project))
                 (completed
                  (perinf-storage-update
                   (perinf-object-id created)
                   '((PERINF_STATUS . completed))
                   project))
                 (reopened
                  (perinf-storage-update
                   (perinf-object-id created)
                   '((PERINF_STATUS . open))
                   project))
                 (cancelled
                  (perinf-storage-update
                   (perinf-object-id created)
                   '((PERINF_STATUS . cancelled))
                   project))
                 (source
                  (with-temp-buffer
                    (insert-file-contents
                     (expand-file-name "data/tasks.org" project))
                    (buffer-string))))
            (should (eq (perinf-object-status active) 'active))
            (should (eq (perinf-object-status waiting) 'waiting))
            (should (eq (perinf-object-status completed) 'completed))
            (should (eq (perinf-object-status reopened) 'open))
            (should (eq (perinf-object-status cancelled) 'cancelled))
            (should (string-match-p "\\* TODO Afslut mig" source))
            (should-not (string-match-p "CLOSED: \\[" source))
            (should (string-match-p
                     ":PERINF_STATUS:[[:space:]]+cancelled"
                     source))
            (should-error
             (perinf-storage-update
              (perinf-object-id created)
              '((PERINF_STATUS . waiting))
              project)
             :type 'user-error)))
      (delete-directory parent t))))

(ert-deftest perinf-test-task-activity-resource-and-last-activity ()
  (let* ((parent (make-temp-file "perinf-task-activity-test-" t))
         (project (expand-file-name "project" parent))
         (work-file (expand-file-name "work-note.org" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Activity test" 'en 'iso 'twenty-four-hour)
          (with-temp-file work-file (insert "work"))
          (let* ((created
                  (perinf-storage-create
                   'task '((title . "Tracked task")) project))
                 (id (perinf-object-id created)))
            (perinf-storage-update
             id '((PERINF_STATUS . active)) project)
            (perinf-storage-start-task-timer id project)
            (perinf-storage-set-task-activity-resource
             id 'file work-file t project)
            (should
             (perinf-storage-touch-task-activity
              id 'file work-file "2026-08-17T10:15:00+02:00" project))
            (let* ((task (car (perinf-storage-list 'task project)))
                   (properties (perinf-object-properties task)))
              (should (equal (alist-get 'TASK_ACTIVITY_FILES properties)
                             (list work-file)))
              (should (equal (alist-get 'TASK_LAST_ACTIVITY_AT properties)
                             "2026-08-17T10:15:00+02:00"))
              (should (equal
                       (alist-get 'TASK_LAST_ACTIVITY_RESOURCE properties)
                       work-file)))))
      (delete-directory parent t))))

(ert-deftest perinf-test-inactive-task-timers-stop-at-exact-boundary ()
  (let* ((parent (make-temp-file "perinf-inactivity-test-" t))
         (project (expand-file-name "project" parent))
         (tasks-file (expand-file-name "data/tasks.org" project))
         (perinf-current-project project)
         (perinf-interface-language 'en)
         (perinf-task-inactivity-timeout 900)
         captured-message)
    (unwind-protect
        (progn
          (perinf-project-create
           project "Inactivity test" 'en 'iso 'twenty-four-hour)
          (with-temp-buffer
            (insert-file-contents tasks-file)
            (goto-char (point-max))
            (insert "\n* TODO Inactive task\n:PROPERTIES:\n"
                    ":ID: task-inactive\n:PERINF_TYPE: task\n"
                    ":PERINF_STATUS: active\n"
                    ":TASK_TIMER_STARTED_AT: 2026-08-17T10:00:00+02:00\n"
                    ":TASK_LAST_ACTIVITY_AT: 2026-08-17T10:05:00+02:00\n"
                    ":TASK_WORK_SECONDS: 7\n:END:\n\n"
                    "* TODO Recent task\n:PROPERTIES:\n"
                    ":ID: task-recent\n:PERINF_TYPE: task\n"
                    ":PERINF_STATUS: active\n"
                    ":TASK_TIMER_STARTED_AT: 2026-08-17T10:20:00+02:00\n"
                    ":TASK_LAST_ACTIVITY_AT: 2026-08-17T10:25:00+02:00\n"
                    ":END:\n")
            (write-region (point-min) (point-max) tasks-file nil 'silent))
          (perinf-i18n-load-locales)
          (cl-letf (((symbol-function 'message)
                     (lambda (format-string &rest args)
                       (setq captured-message
                             (apply #'format format-string args)))))
            (should
             (equal
              (perinf-task-stop-inactive-timers
               (date-to-time "2026-08-17T10:30:00+02:00"))
              '("Inactive task"))))
          (should (string-match-p "Inactive task" captured-message))
          (should (string-match-p "15 minutes" captured-message))
          (let* ((tasks (perinf-storage-list 'task project))
                 (inactive
                  (seq-find
                   (lambda (task)
                     (equal (perinf-object-id task) "task-inactive"))
                   tasks))
                 (recent
                  (seq-find
                   (lambda (task)
                     (equal (perinf-object-id task) "task-recent"))
                   tasks)))
            (should-not
             (alist-get 'TASK_TIMER_STARTED_AT
                        (perinf-object-properties inactive)))
            (should
             (= (string-to-number
                 (alist-get 'TASK_WORK_SECONDS
                            (perinf-object-properties inactive)))
                1207))
            (should
             (alist-get 'TASK_TIMER_STARTED_AT
                        (perinf-object-properties recent)))))
      (delete-directory parent t))))

(ert-deftest perinf-test-reset-running-task-timer-keeps-task-active ()
  (let* ((parent (make-temp-file "perinf-timer-reset-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Timer reset test" 'en 'iso 'twenty-four-hour)
          (let* ((created
                  (perinf-storage-create
                   'task '((title . "Long-running task")) project))
                 (id (perinf-object-id created)))
            (perinf-storage-update
             id '((PERINF_STATUS . active)) project)
            (perinf-storage-start-task-timer id project)
            (let* ((tasks-file (expand-file-name "data/tasks.org" project)))
              (with-temp-buffer
                (insert-file-contents tasks-file)
                (org-mode)
                (should (perinf-storage--find-id id))
                (org-entry-put nil "TASK_WORK_SECONDS" "123")
                (perinf-storage--atomic-write-buffer
                 (current-buffer) tasks-file)))
            (let* ((reset (perinf-storage-reset-task-timer id project))
                   (properties (perinf-object-properties reset)))
              (should (eq (perinf-object-status reset) 'active))
              (should (equal (alist-get 'TASK_WORK_SECONDS properties) "0"))
              (should (alist-get 'TASK_TIMER_STARTED_AT properties)))))
      (delete-directory parent t))))

(ert-deftest perinf-test-time-normalization ()
  (should (equal (perinf-time-normalize "14:30" 'twenty-four-hour)
                 "14:30:00"))
  (should (equal (perinf-time-normalize "2:30 PM" 'twelve-hour)
                 "14:30:00"))
  (should-error
   (perinf-time-normalize "25:00" 'twenty-four-hour)
   :type 'user-error))

(ert-deftest perinf-test-work-task-order ()
  (let* ((completed
          (make-perinf-object
           :id "task-completed" :type 'task :title "Completed"
           :status 'completed :properties '((DEADLINE . "1999-01-01"))))
         (cancelled
          (make-perinf-object
           :id "task-cancelled" :type 'task :title "Cancelled"
           :status 'cancelled :properties '((DEADLINE . "1999-01-01"))))
         (without-deadline
          (make-perinf-object
           :id "task-none" :type 'task :title "No deadline"
           :status 'open :properties '((DEADLINE))))
         (future
          (make-perinf-object
           :id "task-future" :type 'task :title "Future"
           :status 'open :properties '((DEADLINE . "2999-01-01"))))
         (overdue
          (make-perinf-object
           :id "task-overdue" :type 'task :title "Overdue"
           :status 'open :properties '((DEADLINE . "2000-01-01"))))
         (ordered
          (perinf-core--sort-tasks
           (list completed cancelled without-deadline future overdue))))
    (should
     (equal
      (mapcar #'perinf-object-title ordered)
      '("Overdue" "Future" "No deadline" "Cancelled" "Completed")))))

(ert-deftest perinf-test-completed-and-cancelled-archive-categories ()
  (let* ((open-task
          (make-perinf-object
           :id "task-open" :type 'task :title "Open work order"
           :status 'open :properties nil))
         (completed-task
          (make-perinf-object
           :id "task-completed" :type 'task :title "Completed work order"
           :status 'completed :properties nil))
         (cancelled-task
          (make-perinf-object
           :id "task-cancelled" :type 'task :title "Cancelled work order"
           :status 'cancelled :properties nil))
         (held-meeting
          (make-perinf-object
           :id "meeting-held" :type 'meeting :title "Held meeting"
           :status 'held :properties '((START_AT . "2026-08-01T10:00"))))
         (cancelled-meeting
          (make-perinf-object
           :id "meeting-cancelled" :type 'meeting :title "Cancelled meeting"
           :status 'cancelled
           :properties '((START_AT . "2026-08-02T10:00"))))
         (tasks (list open-task completed-task cancelled-task))
         (meetings (list held-meeting cancelled-meeting)))
    (should
     (equal (mapcar #'perinf-object-id (perinf-core--active-tasks tasks))
            '("task-open")))
    (should
     (equal (mapcar #'perinf-object-id
                    (perinf-core--completed-tasks tasks))
            '("task-completed")))
    (should
     (equal (mapcar #'perinf-object-id
                    (perinf-core--archived-meetings meetings))
            '("meeting-held")))
    (should
     (equal (mapcar #'perinf-object-id
                    (perinf-core--cancelled-objects tasks meetings))
            '("meeting-cancelled" "task-cancelled")))))

(ert-deftest perinf-test-meeting-round-trip-through-storage-api ()
  (let* ((parent (make-temp-file "perinf-meeting-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Meeting test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (let* ((created
                  (perinf-storage-create
                   'meeting
                   '((title . "Bestyrelsesmøde")
                     (date . "2026-08-12")
                     (start-time . "14:00:00")
                     (finish-time . "16:00:00")
                     (location . "Lokale 2"))
                   project))
                 (meetings (perinf-storage-list 'meeting project))
                 (meeting (car meetings)))
            (should (file-regular-p (perinf-object-file created)))
            (should (= (length meetings) 1))
            (should (equal (perinf-object-title meeting)
                           "Bestyrelsesmøde"))
            (should (string-prefix-p
                     "2026-08-12T14:00:00"
                     (alist-get 'START_AT
                                (perinf-object-properties meeting))))
            (should (equal
                     (alist-get 'LOCATION
                                (perinf-object-properties meeting))
                     "Lokale 2"))))
      (delete-directory parent t))))

(ert-deftest perinf-test-meeting-status-workflow ()
  (let* ((parent (make-temp-file "perinf-meeting-status-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Meeting status" 'en 'iso 'twenty-four-hour)
          (let* ((meeting
                  (perinf-storage-create
                   'meeting
                   '((title . "Status meeting")
                     (date . "2026-08-12")
                     (start-time . "14:00:00"))
                   project))
                 (meeting-id (perinf-object-id meeting))
                 (postponed
                  (perinf-storage-set-meeting-status
                   meeting-id 'postponed project))
                 (planned-again
                  (perinf-storage-set-meeting-status
                   meeting-id 'planned project))
                 (started
                  (perinf-storage-set-meeting-status
                   meeting-id 'in-progress project))
                 (held
                  (perinf-storage-set-meeting-status
                   meeting-id 'held project)))
            (should (eq (perinf-object-status postponed) 'postponed))
            (should (eq (perinf-object-status planned-again) 'planned))
            (should (eq (perinf-object-status started) 'in-progress))
            (should
             (alist-get
              'ACTUAL_START_AT (perinf-object-properties started)))
            (should (eq (perinf-object-status held) 'held))
            (should
             (alist-get
              'ACTUAL_FINISH_AT (perinf-object-properties held)))
            (should-error
             (perinf-storage-set-meeting-status
              meeting-id 'in-progress project)
             :type 'user-error)
            (let* ((cancel-meeting
                    (perinf-storage-create
                     'meeting
                     '((title . "Cancelled meeting")
                       (date . "2026-08-13")
                       (start-time . "10:00:00"))
                     project))
                   (cancelled
                    (perinf-storage-set-meeting-status
                     (perinf-object-id cancel-meeting)
                     'cancelled project)))
              (should (eq (perinf-object-status cancelled) 'cancelled))
              (should-error
               (perinf-storage-set-meeting-status
                (perinf-object-id cancel-meeting) 'planned project)
               :type 'user-error))))
      (delete-directory parent t))))

(ert-deftest perinf-test-audio-is-managed-and-linked-to-meeting ()
  (let* ((parent (make-temp-file "perinf-audio-test-" t))
         (project (expand-file-name "audio-project" parent))
         (source (expand-file-name "recording.m4a" parent))
         (transcript-source
          (expand-file-name "recording-transcript.txt" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Audio" 'da 'day-month-year-dash
           'twenty-four-hour)
          (with-temp-file source
            (set-buffer-multibyte nil)
            (insert "test-audio-data"))
          (with-temp-file transcript-source
            (insert "Velkommen til mødet.\nDagsordenen blev godkendt.\n"))
          (let* ((meeting
                  (perinf-storage-create
                   'meeting
                   '((title . "Bestyrelsesmøde")
                     (date . "2026-08-12")
                     (start-time . "14:00:00"))
                   project))
                 (audio
                  (perinf-storage-attach-audio
                   (perinf-object-id meeting) source project))
                 (stored-audio
                  (car (perinf-storage-list 'audio-recording project)))
                 (updated-meeting
                  (car (perinf-storage-list 'meeting project)))
                 (managed-file
                  (expand-file-name
                   (alist-get
                    'FILE_REFERENCE
                    (perinf-object-properties stored-audio))
                   project)))
            (should (eq (perinf-object-type audio) 'audio-recording))
            (should (equal (perinf-object-id stored-audio)
                           (perinf-object-id audio)))
            (should (file-regular-p managed-file))
            (should
             (equal
              (perinf-storage--file-sha256 source)
              (alist-get
               'CHECKSUM_SHA256
               (perinf-object-properties stored-audio))))
            (should
             (equal
              (alist-get
               'AUDIO_ID
               (perinf-object-properties updated-meeting))
              (perinf-object-id audio)))
            (should
             (equal
              (alist-get
               'AUDIO_STATUS
               (perinf-object-properties updated-meeting))
              "available"))
            (let* ((transcript
                    (perinf-storage-import-transcript
                     (perinf-object-id meeting)
                     transcript-source
                     project))
                   (stored-transcript
                    (car (perinf-storage-list 'transcript project)))
                   (meeting-with-transcript
                    (car (perinf-storage-list 'meeting project))))
              (should (eq (perinf-object-type transcript) 'transcript))
              (should (equal (perinf-object-id stored-transcript)
                             (perinf-object-id transcript)))
              (should
               (equal
                (alist-get
                 'TRANSCRIPT_ID
                 (perinf-object-properties meeting-with-transcript))
                (perinf-object-id transcript)))
              (should
               (with-temp-buffer
                 (insert-file-contents (perinf-object-file transcript))
                 (search-forward "Dagsordenen blev godkendt." nil t)))
              (should
               (equal
                (perinf-storage-transcript-content stored-transcript)
                (concat "Velkommen til mødet.\n"
                        "Dagsordenen blev godkendt."))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-generated-minutes-require-human-approval ()
  (let* ((parent (make-temp-file "perinf-minutes-test-" t))
         (project (expand-file-name "minutes-project" parent))
         (audio-source (expand-file-name "recording.m4a" parent))
         (transcript-source (expand-file-name "transcript.txt" parent))
         (minutes-source (expand-file-name "minutes.txt" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Minutes" 'en 'iso 'twenty-four-hour)
          (with-temp-file audio-source (insert "audio"))
          (with-temp-file transcript-source (insert "Raw statement."))
          (with-temp-file minutes-source
            (insert "Automatically generated summary."))
          (let* ((meeting
                  (perinf-storage-create
                   'meeting
                   '((title . "Approval meeting")
                     (date . "2026-08-12")
                     (start-time . "14:00:00"))
                   project))
                 (meeting-id (perinf-object-id meeting)))
            (perinf-storage-attach-audio meeting-id audio-source project)
            (perinf-storage-import-transcript
             meeting-id transcript-source project)
            (let* ((draft
                    (perinf-storage-import-generated-minutes
                     meeting-id minutes-source project)))
              (should-error
               (perinf-storage-approve-minutes
                (perinf-object-id draft) "Niels" project)
               :type 'user-error)
              (let* ((submitted
                      (perinf-storage-submit-minutes
                       (perinf-object-id draft) "Referenten" project))
                     (work-view
                      (let ((perinf-current-project
                             (file-name-as-directory project))
                            (perinf-interface-language 'en))
                        (perinf-i18n-load-locales)
                        (with-temp-buffer
                          (perinf-mode)
                          (setq perinf-current-view 'work)
                          (perinf-core--render)
                          (buffer-string))))
                     (home-view
                      (let ((perinf-current-project
                             (file-name-as-directory project))
                            (perinf-interface-language 'en))
                        (perinf-i18n-load-locales)
                        (with-temp-buffer
                          (perinf-mode)
                          (setq perinf-current-view 'home)
                          (perinf-core--render)
                          (buffer-string))))
                     (rejected
                      (perinf-storage-reject-minutes
                       (perinf-object-id draft)
                       "Formanden"
                       "Beslutningen mangler."
                       project))
                     (resubmitted
                      (perinf-storage-submit-minutes
                       (perinf-object-id draft) "Referenten" project))
                     (_tampered
                      (with-temp-buffer
                        (insert-file-contents (perinf-object-file draft))
                        (goto-char (point-min))
                        (search-forward "Automatically generated summary.")
                        (replace-match "Reviewed and corrected summary." t t)
                        (write-region
                         (point-min) (point-max)
                         (perinf-object-file draft) nil 'silent)))
                     (_changed-approval
                      (should-error
                       (perinf-storage-approve-minutes
                        (perinf-object-id draft) "Niels" project)
                       :type 'user-error))
                     (_rejected-after-change
                      (perinf-storage-reject-minutes
                       (perinf-object-id draft)
                       "Formanden"
                       "Den ændrede tekst skal genindsendes."
                       project))
                     (_submitted-after-change
                      (perinf-storage-submit-minutes
                       (perinf-object-id draft) "Referenten" project))
                   (approved
                    (perinf-storage-approve-minutes
                     (perinf-object-id draft) "Niels" project))
                   (sourced-decision
                    (perinf-storage-create
                     'decision
                     `((title . "Approve the annual plan")
                       (date . "2026-08-12")
                       (rationale . "Recorded in the approved minutes.")
                       (meeting-id . ,meeting-id)
                       (minutes-id . ,(perinf-object-id approved)))
                     project))
                   (sourced-task
                    (perinf-storage-create
                     'task
                     `((title . "Implement the approved plan")
                       (decision-id
                        . ,(perinf-object-id sourced-decision))
                       (meeting-id . ,meeting-id)
                       (minutes-id . ,(perinf-object-id approved)))
                     project))
                   (decision-detail-view
                    (let ((perinf-current-project
                           (file-name-as-directory project))
                          (perinf-interface-language 'en))
                      (perinf-i18n-load-locales)
                      (with-temp-buffer
                        (perinf-mode)
                        (setq perinf-current-view 'detail
                              perinf-selected-object sourced-decision)
                        (perinf-core--render)
                        (buffer-string))))
                   (updated-meeting
                    (car (perinf-storage-list 'meeting project)))
                   (records-view
                    (let ((perinf-current-project
                           (file-name-as-directory project))
                          (perinf-interface-language 'en))
                      (perinf-i18n-load-locales)
                      (with-temp-buffer
                        (perinf-mode)
                        (setq perinf-current-view 'records)
                        (perinf-core--render)
                        (buffer-string))))
                   (minutes-detail-view
                    (let ((perinf-current-project
                           (file-name-as-directory project))
                          (perinf-interface-language 'en))
                      (perinf-i18n-load-locales)
                      (with-temp-buffer
                        (perinf-mode)
                        (setq perinf-current-view 'detail
                              perinf-selected-object approved)
                        (perinf-core--render)
                        (buffer-string))))
                   (meeting-detail-view
                    (let ((perinf-current-project
                           (file-name-as-directory project))
                          (perinf-interface-language 'en))
                      (perinf-i18n-load-locales)
                      (with-temp-buffer
                        (perinf-mode)
                        (setq perinf-current-view 'detail
                              perinf-selected-object updated-meeting)
                        (perinf-core--render)
                        (buffer-string)))))
              (should (eq (perinf-object-status draft) 'ai-draft))
              (should (eq (perinf-object-status submitted)
                          'awaiting-final-approval))
              (should (string-match-p
                       "Minutes awaiting final approval" work-view))
              (should (string-match-p
                       "Draft minutes — Approval meeting" work-view))
              (should (string-match-p "Approve minutes" work-view))
              (should (string-match-p "Raw transcripts: 1" home-view))
              (should (string-match-p "Minutes: 1" home-view))
              (should (string-match-p
                       "Minutes awaiting final approval: 1" home-view))
              (should (eq (perinf-object-status rejected) 'rejected))
              (should (equal
                       (alist-get
                        'REJECTION_REASON
                        (perinf-object-properties rejected))
                       "Beslutningen mangler."))
              (should (eq (perinf-object-status resubmitted)
                          'awaiting-final-approval))
              (should (equal
                       (alist-get
                        'SUBMITTED_BY
                        (perinf-object-properties submitted))
                       "Referenten"))
              (should (equal
                       (perinf-storage-minutes-content draft)
                       "Reviewed and corrected summary."))
              (should (eq (perinf-object-status approved)
                          'final-approved))
              (should (equal
                       (alist-get
                        'APPROVED_BY (perinf-object-properties approved))
                       "Niels"))
              (should (equal
                       (alist-get
                        'APPROVED_CONTENT_CHECKSUM_SHA256
                        (perinf-object-properties approved))
                       (alist-get
                        'CONTENT_CHECKSUM_SHA256
                       (perinf-object-properties approved))))
              (should (equal
                       (alist-get
                        'MEETING_ID
                        (perinf-object-properties sourced-decision))
                       meeting-id))
              (should (equal
                       (alist-get
                        'MINUTES_ID
                        (perinf-object-properties sourced-decision))
                       (perinf-object-id approved)))
              (should (equal
                       (alist-get
                        'MEETING_ID
                        (perinf-object-properties sourced-task))
                       meeting-id))
              (should (string-match-p
                       "Tasks from this decision"
                       decision-detail-view))
              (should (string-match-p
                       "Implement the approved plan"
                       decision-detail-view))
              (should (string-match-p
                       "Decisions from this meeting"
                       meeting-detail-view))
              (should (string-match-p
                       "Approve the annual plan"
                       meeting-detail-view))
              (should (string-match-p
                       "Tasks from this meeting"
                       meeting-detail-view))
              (should (string-match-p
                       "Implement the approved plan"
                       meeting-detail-view))
              (should (string-match-p
                       "Register decision from these minutes"
                       minutes-detail-view))
              (should (string-match-p
                       "Decisions from these minutes"
                       minutes-detail-view))
              (should (string-match-p
                       "Approve the annual plan"
                       minutes-detail-view))
              (should (string-match-p
                       "Tasks from these minutes"
                       minutes-detail-view))
              (should (string-match-p
                       "Implement the approved plan"
                       minutes-detail-view))
              (should (equal
                       (alist-get
                        'MINUTES_STATUS
                        (perinf-object-properties updated-meeting))
                       "final-approved"))
              (should (string-match-p "Raw transcripts" records-view))
              (should (string-match-p "Raw transcript" records-view))
              (should (string-match-p
                       "Draft minutes — Approval meeting" records-view))
              (should (string-match-p
                       "Human-approved final version" records-view))
              (let* ((perinf-current-project
                      (file-name-as-directory project))
                     (results
                      (perinf-core--search-objects "Approval meeting"))
                     (types (mapcar #'perinf-object-type results)))
                (should (= (length results) 3))
                (should (memq 'meeting types))
                (should (memq 'transcript types))
                (should (memq 'minutes types)))
              (should
               (with-temp-buffer
                 (insert-file-contents (perinf-object-file approved))
                 (and (search-forward ":REVIEW_EVENT:   rejected" nil t)
                      (search-forward ":REVIEW_EVENT:   submitted" nil t)
                      (search-forward
                       ":REVIEW_EVENT:   approved" nil t))))
              (let ((events
                     (perinf-storage-list-review-events approved)))
                (should
                 (equal
                  (mapcar
                   (lambda (event) (alist-get 'event event))
                   events)
                  '("submitted" "rejected" "submitted"
                    "rejected" "submitted" "approved")))
                (should
                 (equal
                  (alist-get 'reason (nth 1 events))
                  "Beslutningen mangler.")))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-person-round-trip-through-storage-api ()
  (let* ((parent (make-temp-file "perinf-person-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Person test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (let* ((created
                  (perinf-storage-create
                   'person
                   '((title . "Anne Jensen")
                     (email . "anne@example.dk")
                     (phone . "+45 12 34 56 78"))
                   project))
                 (people (perinf-storage-list 'person project))
                 (person (car people)))
            (should (string-prefix-p "person-" (perinf-object-id created)))
            (should (= (length people) 1))
            (should (equal (perinf-object-title person) "Anne Jensen"))
            (should (equal
                     (alist-get 'EMAIL
                                (perinf-object-properties person))
                     "anne@example.dk"))
            (should (equal
                     (alist-get 'PHONE
                                (perinf-object-properties person))
                     "+45 12 34 56 78"))))
      (delete-directory parent t))))

(ert-deftest perinf-test-person-groups-expand-to-stable-person-references ()
  (let* ((parent (make-temp-file "perinf-group-test-" t))
         (project (expand-file-name "project" parent))
         (perinf-interface-language 'da))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Groups" 'da 'day-month-year-dash 'twenty-four-hour)
          (let* ((anne (perinf-storage-create
                        'person '((title . "Anne Jensen")) project))
                 (bo (perinf-storage-create
                      'person '((title . "Bo Nielsen")) project))
                 (ids (list (perinf-object-id anne) (perinf-object-id bo)))
                 (group (perinf-storage-create
                         'person-group
                         `((title . "Bestyrelsen") (member-ids . ,ids))
                         project))
                 (task (perinf-storage-create
                        'task '((title . "Læs materialet")) project))
                 (meeting (perinf-storage-create
                           'meeting
                           '((title . "Gruppemøde")
                             (date . "2026-08-19")
                             (start-time . "10:00:00"))
                           project))
                 (assigned
                  (perinf-storage-assign-task
                   (perinf-object-id task)
                   (perinf-storage-group-member-ids group)
                   project))
                 (perinf-current-project (file-name-as-directory project)))
            (should (equal (perinf-storage-task-assignee-ids assigned) ids))
            (should-not
             (alist-get 'ASSIGNEE_ID (perinf-object-properties assigned)))
            (cl-letf (((symbol-function 'perinf-meeting--select-person)
                       (lambda () ids))
                      ((symbol-function 'perinf-meeting--select-role)
                       (lambda () 'participant))
                      ((symbol-function 'perinf-core-meetings) #'ignore))
              (perinf-meeting-add-participant (perinf-object-id meeting)))
            (should (= 2 (length
                          (perinf-storage-list-children
                           (perinf-object-id meeting) 'participants project))))
            (perinf-storage-update-person
             (perinf-object-id anne) "Anne Hansen" "anne@example.dk" "1234"
             project)
            (should (equal
                     (perinf-object-title
                      (car (perinf-storage-list 'person project)))
                     "Anne Hansen"))
            (perinf-storage-update-person-group
             (perinf-object-id group) "Arbejdsgruppen"
             (list (perinf-object-id anne)) project)
            (let ((updated-group (car (perinf-storage-list 'person-group project))))
              (should (equal (perinf-object-title updated-group)
                             "Arbejdsgruppen"))
              (should (equal (perinf-storage-group-member-ids updated-group)
                             (list (perinf-object-id anne)))))
            ;; The already assigned task keeps its original person references.
            (should (equal
                     (perinf-storage-task-assignee-ids
                      (car (perinf-storage-list 'task project)))
                     ids))
            (perinf-storage-set-person-group-status
             (perinf-object-id group) 'inactive project)
            (perinf-i18n-load-locales)
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'people)
              (perinf-core--render)
              (should (string-match-p "Personer og grupper" (buffer-string)))
              (should (string-match-p "Arbejdsgruppen" (buffer-string)))
              (should-not (string-match-p "Slet permanent" (buffer-string))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-decision-round-trip-records-and-search ()
  (let* ((parent (make-temp-file "perinf-decision-test-" t))
         (project (expand-file-name "project" parent))
         (perinf-interface-language 'en))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Decisions" 'en 'iso 'twenty-four-hour)
          (let* ((created
                  (perinf-storage-create
                   'decision
                   '((title . "Adopt the annual plan")
                     (date . "2026-08-12")
                     (rationale . "The budget was approved."))
                   project))
                 (decisions (perinf-storage-list 'decision project))
                 (decision (car decisions))
                 (task
                  (perinf-storage-create
                   'task
                   `((title . "Implement the annual plan")
                     (decision-id . ,(perinf-object-id decision)))
                   project))
                 (person
                  (perinf-storage-create
                   'person '((title . "Anne Jensen")) project))
                 (assigned-task
                  (perinf-storage-assign-task
                   (perinf-object-id task)
                   (perinf-object-id person)
                   project))
                 (meeting
                  (perinf-storage-create
                   'meeting
                   '((title . "Planning meeting")
                     (date . "2026-08-12")
                     (start-time . "14:00:00"))
                   project))
                 (_participant
                  (perinf-storage-add-child
                   (perinf-object-id meeting)
                   'participants
                   'participant
                   `((PERSON_ID . ,(perinf-object-id person))
                     (PARTICIPANT_ROLE . chair)
                     (ATTENDANCE_STATUS . invited))
                   project))
                 (perinf-current-project
                  (file-name-as-directory project)))
            (should (equal (perinf-object-id created)
                           (perinf-object-id decision)))
            (should (equal
                     (alist-get
                      'DECIDED_ON (perinf-object-properties decision))
                     "2026-08-12"))
            (should (equal
                     (alist-get
                      'RATIONALE (perinf-object-properties decision))
                     "The budget was approved."))
            (should
             (eq
              (perinf-object-type
               (car (perinf-core--search-objects "annual plan")))
              'decision))
            (should (equal
                     (alist-get
                      'DECISION_ID (perinf-object-properties task))
                     (perinf-object-id decision)))
            (should (equal
                     (alist-get
                      'ASSIGNEE_ID
                      (perinf-object-properties assigned-task))
                     (perinf-object-id person)))
            (perinf-i18n-load-locales)
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'records)
              (perinf-core--render)
              (should (string-match-p "Decisions" (buffer-string)))
              (should
               (string-match-p "Adopt the annual plan" (buffer-string))))
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'detail
                    perinf-selected-object decision)
              (perinf-core--render)
              (should
               (string-match-p
                "Create task from this decision" (buffer-string))))
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'detail
                    perinf-selected-object assigned-task)
              (perinf-core--render)
              (should (string-match-p
                       "Source decision: Adopt the annual plan"
                       (buffer-string)))
              (should
               (string-match-p "Responsible: Anne Jensen"
                               (buffer-string))))
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'work)
              (perinf-core--render)
              (should
               (string-match-p "Responsible: Anne Jensen"
                               (buffer-string))))
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'detail
                    perinf-selected-object person)
              (perinf-core--render)
              (should (string-match-p "Assigned tasks" (buffer-string)))
              (should
               (string-match-p
                "Implement the annual plan" (buffer-string)))
              (should (string-match-p "Meetings" (buffer-string)))
              (should (string-match-p "Planning meeting" (buffer-string)))
              (should (string-match-p "Chair" (buffer-string))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-context-round-trip-records-and-search ()
  (let* ((parent (make-temp-file "perinf-context-test-" t))
         (project (expand-file-name "project" parent))
         (perinf-interface-language 'en))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Contexts" 'en 'iso 'twenty-four-hour)
          (let* ((created
                  (perinf-storage-create
                   'context
                   '((title . "Municipal work")
                     (description . "Work involving the municipality."))
                   project))
                 (context
                  (car (perinf-storage-list 'context project)))
                 (task
                  (perinf-storage-create
                   'task '((title . "Call the municipality")) project))
                 (context-task
                  (perinf-storage-set-task-context
                   (perinf-object-id task)
                   (perinf-object-id context)
                   project))
                 (perinf-current-project
                  (file-name-as-directory project)))
            (should (equal (perinf-object-id created)
                           (perinf-object-id context)))
            (should (equal
                     (alist-get
                      'DESCRIPTION (perinf-object-properties context))
                     "Work involving the municipality."))
            (should (equal
                     (alist-get
                      'CONTEXT_ID
                      (perinf-object-properties context-task))
                     (perinf-object-id context)))
            (should
             (seq-find
              (lambda (object)
                (eq (perinf-object-type object) 'context))
              (perinf-core--search-objects "Municipal")))
            (perinf-i18n-load-locales)
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'records)
              (perinf-core--render)
              (should (string-match-p "Contexts" (buffer-string)))
              (should (string-match-p "Municipal work" (buffer-string))))
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'work)
              (perinf-core--render)
              (should
               (string-match-p "Context: Municipal work"
                               (buffer-string))))
            (with-temp-buffer
              (perinf-mode)
              (setq perinf-current-view 'detail
                    perinf-selected-object context)
              (perinf-core--render)
              (should
               (string-match-p "Tasks in this context" (buffer-string)))
              (should
               (string-match-p "Call the municipality"
                               (buffer-string))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-add-person-to-meeting-by-stable-id ()
  (let* ((parent (make-temp-file "perinf-participant-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Participant test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (let* ((person
                  (perinf-storage-create
                   'person '((title . "Anne Jensen")) project))
                 (meeting
                  (perinf-storage-create
                   'meeting
                   '((title . "Bestyrelsesmøde")
                     (date . "2026-08-12")
                     (start-time . "14:00:00")
                     (finish-time . "16:00:00"))
                   project))
                 (participant-id
                  (perinf-storage-add-child
                   (perinf-object-id meeting)
                   'participants
                   'participant
                   `((PERSON_ID . ,(perinf-object-id person))
                     (PARTICIPANT_ROLE . secretary)
                     (ATTENDANCE_STATUS . invited))
                   project))
                 (participants
                  (perinf-storage-list-children
                   (perinf-object-id meeting) 'participants project))
                 (participant (car participants))
                 (attended
                  (perinf-storage-set-attendance
                   (perinf-object-id meeting)
                   participant-id
                   'attended
                   project)))
            (should (string-prefix-p "participant-" participant-id))
            (should (= (length participants) 1))
            (should (equal
                     (alist-get 'PERSON_ID
                                (perinf-object-properties participant))
                     (perinf-object-id person)))
            (should (eq
                     (alist-get 'PARTICIPANT_ROLE
                                (perinf-object-properties participant))
                     'secretary))
            (should (eq
                     (alist-get
                      'ATTENDANCE_STATUS
                      (perinf-object-properties attended))
                     'attended))
            (should-error
             (perinf-storage-set-attendance
              (perinf-object-id meeting)
              participant-id
              'unknown
              project)
             :type 'user-error)
            (let ((perinf-current-project
                   (file-name-as-directory project))
                  (perinf-interface-language 'da))
              (perinf-i18n-load-locales)
              (with-temp-buffer
                (perinf-mode)
                (setq perinf-current-view 'detail
                      perinf-selected-object
                      (car (perinf-storage-list 'meeting project)))
                (perinf-core--render)
                (should (string-match-p "Referent" (buffer-string)))
                (should (string-match-p "Deltog" (buffer-string))))
              (with-temp-buffer
                (perinf-mode)
                (setq perinf-current-view 'detail
                      perinf-selected-object
                      (car (perinf-storage-list 'person project)))
                (perinf-core--render)
                (should
                 (string-match-p "Bestyrelsesmøde" (buffer-string)))
                (should (string-match-p "Referent" (buffer-string)))
                (should (string-match-p "Deltog" (buffer-string)))))
            (should-error
             (perinf-storage-add-child
              (perinf-object-id meeting)
              'participants
              'participant
              `((PERSON_ID . ,(perinf-object-id person)))
              project)
             :type 'user-error)))
      (delete-directory parent t))))

(ert-deftest perinf-test-add-agenda-item-to-meeting ()
  (let* ((parent (make-temp-file "perinf-agenda-test-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Agenda test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (let* ((meeting
                  (perinf-storage-create
                   'meeting
                   '((title . "Bestyrelsesmøde")
                     (date . "2026-08-12")
                     (start-time . "14:00:00"))
                   project))
                 (item-id
                  (perinf-storage-add-child
                   (perinf-object-id meeting)
                   'agenda
                   'agenda-item
                   '((title . "Budget 2027")
                     (AGENDA_NUMBER . "3")
                     (AGENDA_KIND . decision))
                   project))
                 (items
                  (perinf-storage-list-children
                   (perinf-object-id meeting) 'agenda project))
                 (item (car items)))
            (should (string-prefix-p "agenda-item-" item-id))
            (should (= (length items) 1))
            (should (equal (perinf-object-title item) "Budget 2027"))
            (should (equal
                     (alist-get 'AGENDA_NUMBER
                                (perinf-object-properties item))
                     "3"))
            (should (eq
                     (alist-get 'AGENDA_KIND
                                (perinf-object-properties item))
                     'decision))
            (should-error
             (perinf-storage-add-child
              (perinf-object-id meeting)
              'agenda
              'agenda-item
              '((title . "Et andet punkt")
                (AGENDA_NUMBER . "3")
                (AGENDA_KIND . discussion))
              project)
             :type 'user-error)))
      (delete-directory parent t))))

(ert-deftest perinf-test-cancel-agenda-item-without-writing ()
  (let* ((parent (make-temp-file "perinf-agenda-cancel-test-" t))
         (project (expand-file-name "project" parent))
         (previously-bound (boundp 'perinf-current-project))
         (previous-project (and previously-bound perinf-current-project))
         (write-called nil))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Agenda cancel test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (setq perinf-current-project project)
          (cl-letf (((symbol-function 'read-string)
                     (lambda (&rest _arguments) ""))
                    ((symbol-function 'perinf-storage-add-child)
                     (lambda (&rest _arguments)
                       (setq write-called t))))
            (perinf-meeting-add-agenda-item "meeting-not-needed"))
          (should-not write-called))
      (if previously-bound
          (setq perinf-current-project previous-project)
        (makunbound 'perinf-current-project))
      (delete-directory parent t))))

(ert-deftest perinf-test-documents-are-managed-for-meeting-and-agenda-item ()
  (let* ((parent (make-temp-file "perinf-document-test-" t))
         (project (expand-file-name "project" parent))
         (source (expand-file-name "meeting-material.txt" parent)))
    (unwind-protect
        (progn
          (perinf-project-create
           project "Document test" 'da 'day-month-year-dash
           'twenty-four-hour)
          (with-temp-file source
            (insert "Controlled meeting material\n"))
          (let* ((meeting
                  (perinf-storage-create
                   'meeting
                   '((title . "Document meeting")
                     (date . "2026-08-12")
                     (start-time . "14:00:00"))
                   project))
                 (meeting-id (perinf-object-id meeting))
                 (item-id
                  (perinf-storage-add-child
                   meeting-id 'agenda 'agenda-item
                   '((title . "Documented item")
                     (AGENDA_NUMBER . "1")
                     (AGENDA_KIND . discussion))
                   project))
                 (meeting-document
                  (perinf-storage-attach-document
                   meeting-id nil source project))
                 (item-document
                  (perinf-storage-attach-document
                   meeting-id item-id source project))
                 (documents (perinf-storage-list 'document project)))
            (should (= (length documents) 2))
            (should (equal
                     (alist-get 'PARENT_TYPE
                                (perinf-object-properties meeting-document))
                     "meeting"))
            (should (equal
                     (alist-get 'AGENDA_ITEM_ID
                                (perinf-object-properties item-document))
                     item-id))
            (should (file-exists-p source))
            (dolist (document documents)
              (let ((properties (perinf-object-properties document)))
                (should (= (length (alist-get 'CHECKSUM_SHA256 properties)) 64))
                (should
                 (file-exists-p
                  (expand-file-name
                   (alist-get 'FILE_REFERENCE properties) project)))))))
      (delete-directory parent t))))

;;; perinf-test.el ends here

(ert-deftest perinf-test-memo-capture-persists-category-and-cancels ()
  (let* ((parent (make-temp-file "perinf-memo-test-" t))
         (project (expand-file-name "project" parent))
         (perinf-current-project project)
         (org-id-locations nil)
         (org-id-track-globally nil)
         (org-capture-after-finalize-hook nil)
         (org-capture-prepare-finalize-hook nil))
    (unwind-protect
        (progn
          (perinf-project-create project "Memo test" 'da 'iso 'twenty-four-hour)
          (dolist (locale perinf-i18n-supported-locales)
            (let ((perinf-interface-language locale))
              (save-window-excursion
                (cl-letf (((symbol-function 'org-read-date)
                           (lambda (&rest _)
                             (setq org-time-was-given nil)
                             (encode-time 0 0 0 15 9 2026))))
                  (perinf-capture-memo))
                (insert (format "Test %s" locale))
                (org-capture-finalize))))
          (with-current-buffer (find-file-noselect (perinf-memo--file))
            (goto-char (point-min))
            (let ((count 0))
              (org-map-entries
               (lambda ()
                 (setq count (1+ count))
                 (should (equal (org-entry-get nil "CATEGORY" nil)
                                "Husk"))
                 (should (org-entry-get nil "ID"))
                 (should (org-entry-get nil "CREATED"))
                 (should (string-prefix-p "<2026-09-15"
                                          (org-entry-get nil "SCHEDULED")))
                 (should-not (org-get-todo-state))))
              (should (= count 5)))
            (let ((before (buffer-string)))
              (save-window-excursion
                (cl-letf (((symbol-function 'org-read-date)
                           (lambda (&rest _)
                             (setq org-time-was-given nil)
                             (encode-time 0 0 0 15 9 2026))))
                  (perinf-capture-memo))
                (insert "Cancelled memo")
                (org-capture-kill))
              (should (equal (string-trim-right before)
                             (string-trim-right (buffer-string))))))
          (let ((perinf-current-project nil))
            (should-error (perinf-memo--file) :type 'user-error)))
      (dolist (buffer (buffer-list))
        (when-let* ((file (buffer-file-name buffer)))
          (when (file-in-directory-p file parent)
            (with-current-buffer buffer (set-buffer-modified-p nil))
            (kill-buffer buffer))))
      (delete-directory parent t))))

(ert-deftest perinf-test-memo-close-button-saves-and-preserves-note ()
  (let* ((parent (make-temp-file "perinf-close-" t))
         (project (expand-file-name "project" parent))
         (auto-insert nil)
         (refreshed nil)
         (perinf-memo-after-close-hook (list (lambda () (setq refreshed t)))))
    (unwind-protect
        (save-window-excursion
          (perinf-project-create project "Close test" 'da 'iso 'twenty-four-hour)
          (with-temp-file (expand-file-name "data/memos.org" project)
            (insert "* Remember this\n:PROPERTIES:\n:ID: memo-close-test\n:CATEGORY: Husk\n:END:\nKeep this text.\n"))
          (perinf-memo-open (car (perinf-memo-list project)))
          (should perinf-memo-controls-mode)
          (should (eq (lookup-key perinf-memo--header-map [header-line mouse-1])
                      #'perinf-memo--close-click))
          (let ((window (selected-window)))
            (cl-letf (((symbol-function 'event-start) (lambda (_) 'test-position))
                      ((symbol-function 'posn-window) (lambda (_) window)))
              (perinf-memo--close-click 'test-event)))
          (should refreshed)
          (should-not (perinf-memo-list project))
          (with-temp-buffer
            (insert-file-contents (expand-file-name "data/memos.org" project))
            (should (string-match-p "^\\* DONE Remember this" (buffer-string)))
            (should (string-match-p ":CATEGORY: Husk" (buffer-string)))
            (should (string-match-p "Keep this text" (buffer-string)))))
      (dolist (buffer (buffer-list))
        (when-let* ((file (buffer-file-name buffer))
                    ((file-in-directory-p file parent)))
          (kill-buffer buffer)))
      (delete-directory parent t))))

(ert-deftest perinf-test-meeting-date-only-create-and-edit ()
  "Create a meeting without times, add them later, and remove them again."
  (let* ((parent (make-temp-file "perinf-date-only-" t))
         (project (expand-file-name "project" parent))
         (perinf-current-project project))
    (unwind-protect
        (save-window-excursion
          (perinf-project-create project "Date only" 'da 'iso 'twenty-four-hour)
          (let* ((answers (list "Date only meeting" "2026-09-15" "" "  " "Room"))
                 (meeting
                  (cl-letf (((symbol-function 'read-string)
                             (lambda (&rest _) (pop answers))))
                    (perinf-meeting-create)))
                 (id (perinf-object-id meeting)))
            (should (equal (alist-get 'START_AT (perinf-object-properties meeting))
                           "2026-09-15"))
            (should-not (alist-get 'FINISH_AT (perinf-object-properties meeting)))
            (dolist (times '(("" "") ("14:00" "15:00") ("" "")))
              (let ((answers (append (list "Date only meeting" "2026-09-15")
                                     times (list "Room"))))
                (cl-letf (((symbol-function 'read-string)
                           (lambda (&rest _) (pop answers))))
                  (perinf-meeting-edit id)))
              (let* ((saved (car (perinf-storage-list 'meeting project)))
                     (properties (perinf-object-properties saved)))
                (should (equal (perinf-object-id saved) id))
                (if (equal (car times) "")
                    (progn
                      (should (equal (alist-get 'START_AT properties) "2026-09-15"))
                      (should-not (alist-get 'FINISH_AT properties)))
                  (should (string-prefix-p "2026-09-15T14:00:00"
                                           (alist-get 'START_AT properties)))
                  (should (string-prefix-p "2026-09-15T15:00:00"
                                           (alist-get 'FINISH_AT properties)))))
              (perinf-core-meetings))))
      (dolist (buffer (buffer-list))
        (when-let* ((file (buffer-file-name buffer)))
          (when (file-in-directory-p file parent)
            (with-current-buffer buffer (set-buffer-modified-p nil))
            (kill-buffer buffer))))
      (delete-directory parent t))))

(ert-deftest perinf-test-meeting-date-only-validation ()
  "Reject invalid input without creating or changing a meeting file."
  (let* ((parent (make-temp-file "perinf-date-validation-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create project "Validation" 'da 'iso 'twenty-four-hour)
          (dolist (data '(((date . "2026-02-30"))
                          ((date . ""))
                          ((date . nil))
                          ((date . "2026-09-15") (start-time . "25:00:00"))
                          ((date . "2026-09-15") (finish-time . "25:00:00"))
                          ((date . "2026-09-15") (start-time . "15:00:00")
                           (finish-time . "14:00:00"))))
            (should-error
             (perinf-storage-create 'meeting (cons '(title . "Invalid") data) project))
            (should-not (perinf-storage-list 'meeting project)))
          (let* ((meeting (perinf-storage-create
                           'meeting '((title . "Valid") (date . "2026-09-15"))
                           project))
                 (file (perinf-object-file meeting))
                 (before (with-temp-buffer
                           (insert-file-contents file) (buffer-string))))
            (should-error
             (perinf-storage-update-meeting
              (perinf-object-id meeting)
              '((title . "Invalid") (date . "2026-02-30")) project))
            (should (equal before (with-temp-buffer
                                    (insert-file-contents file) (buffer-string))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-meeting-one-known-time ()
  "Preserve an independently supplied start or finish time."
  (let* ((parent (make-temp-file "perinf-one-time-" t))
         (project (expand-file-name "project" parent)))
    (unwind-protect
        (progn
          (perinf-project-create project "One time" 'da 'iso 'twenty-four-hour)
          (dolist (time '((start-time . "14:00:00") (finish-time . "15:00:00")))
            (let* ((meeting (perinf-storage-create
                             'meeting (list '(title . "One time")
                                            '(date . "2026-09-15") time) project))
                   (saved (perinf-storage--meeting-by-id
                           (perinf-object-id meeting) project))
                   (properties (perinf-object-properties saved)))
              (if (eq (car time) 'start-time)
                  (progn
                    (should (string-prefix-p "2026-09-15T14:00:00"
                                             (alist-get 'START_AT properties)))
                    (should-not (alist-get 'FINISH_AT properties)))
                (should (equal (alist-get 'START_AT properties) "2026-09-15"))
                (should (string-prefix-p "2026-09-15T15:00:00"
                                         (alist-get 'FINISH_AT properties)))))))
      (delete-directory parent t))))

(ert-deftest perinf-test-clock-lines-update-hidden-and-stop-on-kill ()
  (let* ((parent (make-temp-file "perinf-clock-test-" t))
         (project (expand-file-name "project" parent))
         (buffer (generate-new-buffer " *PerInf clock test*"))
         (perinf-current-project project)
         (perinf-interface-language 'en)
         (now (date-to-time "2026-09-15T10:00:00+02:00"))
         display-timer)
    (unwind-protect
        (cl-letf (((symbol-function 'current-time) (lambda () now))
                  ((symbol-function 'perinf-storage--iso-now)
                   (lambda () (format-time-string "%Y-%m-%dT%H:%M:%S%:z" now))))
          (perinf-i18n-load-locales)
          (perinf-project-create project "Clock Project" 'en 'iso 'twenty-four-hour)
          (dolist (title '("First clock" "Second clock"))
            (let ((task (perinf-storage-create 'task `((title . ,title)) project)))
              (perinf-storage-update
               (perinf-object-id task)
               '((PERINF_STATUS . active)) project)
              (setq now (time-subtract now 60))
              (perinf-storage-start-task-timer (perinf-object-id task) project)
              (setq now (time-add now 60))
              (perinf-storage-stop-task-timer (perinf-object-id task) project now)
              (perinf-storage-start-task-timer (perinf-object-id task) project)))
          (with-current-buffer buffer
            (perinf-mode)
            (perinf-core--render)
            (setq display-timer perinf-core--clock-timer)
            (should (= (timer--repeat-delay display-timer) 5))
            (should (string-match-p "CP · First clock · 0:01:00" (buffer-string)))
            (should (string-match-p "CP · Second clock · 0:01:00" (buffer-string)))
            (should (plist-get (get-text-property perinf-core--clock-start 'face) :box))
            (perinf-core--render)
            (should (eq display-timer perinf-core--clock-timer))
            (goto-char (point-max)))
          ;; Hiding the buffer leaves both persistent clocks running.
          (bury-buffer buffer)
          (should-not (get-buffer-window buffer t))
          (setq now (time-add now 5))
          (perinf-core--update-clocks buffer)
          (with-current-buffer buffer
            (should (= (point) (point-max)))
            (should (string-match-p "CP · First clock · 0:01:05" (buffer-string)))
            (should (string-match-p "CP · Second clock · 0:01:05" (buffer-string))))
          (dolist (task (perinf-storage-list 'task project))
            (should (alist-get 'TASK_TIMER_STARTED_AT (perinf-object-properties task))))
          ;; A failed save must not discard the owner buffer or its timer.
          (cl-letf (((symbol-function 'perinf-storage-stop-task-timer)
                     (lambda (&rest _) (error "Test write failure"))))
            (should-error (kill-buffer buffer))
            (should (buffer-live-p buffer))
            (should (memq display-timer timer-list)))
          (kill-buffer buffer)
          (should-not (buffer-live-p buffer))
          (should-not (memq display-timer timer-list))
          (dolist (task (perinf-storage-list 'task project))
            (should-not (alist-get 'TASK_TIMER_STARTED_AT (perinf-object-properties task)))
            (should (= 65 (perinf-task-total-work-seconds task)))
            (should (eq 'active (perinf-object-status task)))))
      (when (buffer-live-p buffer) (kill-buffer buffer))
      (delete-directory parent t))))

(ert-deftest perinf-test-clocks-retain-project-ownership-across-views ()
  (let ((buffer (generate-new-buffer " *PerInf clock ownership*"))
        (running '("/tmp/perinf-clock-a/" "/tmp/perinf-clock-b/"))
        stopped)
    (cl-letf (((symbol-function 'perinf-storage-read-project)
               (lambda (_) '((PROJECT_TITLE . "Test Project"))))
              ((symbol-function 'perinf-storage-list)
               (lambda (_type project)
                 (when (member project running)
                   (list (make-perinf-object
                          :id "same-id" :title project :type 'task :status 'active
                          :properties '((TASK_TIMER_STARTED_AT . "2026-09-15T10:00:00+02:00")))))))
              ((symbol-function 'perinf-storage-stop-task-timer)
               (lambda (_id project &optional _now)
                 (push project stopped))))
      (unwind-protect
          (with-current-buffer buffer
            (perinf-mode)
            (let ((inhibit-read-only t)
                  (perinf-current-project "/tmp/perinf-clock-a/"))
              (perinf-core--insert-clocks)
              (setq perinf-current-project "/tmp/perinf-clock-b/")
              (erase-buffer)
              (perinf-core--insert-clocks)
              (should (= 2 (length perinf-core--clock-projects)))
              (should (string-match-p "perinf-clock-a" (buffer-string)))
              (should (string-match-p "perinf-clock-b" (buffer-string)))
              ;; A stopped clock disappears on the next tick.
              (setq running '("/tmp/perinf-clock-b/"))
              (perinf-core--update-clocks buffer)
              (should-not (string-match-p "perinf-clock-a" (buffer-string)))
              (should (string-match-p "perinf-clock-b" (buffer-string)))
              (setq perinf-current-project "/tmp/unrelated-project/")
              (kill-buffer buffer)
              (should (equal stopped '("/tmp/perinf-clock-b/")))))
        (when (buffer-live-p buffer) (kill-buffer buffer))))))
